/**
 * Created by Brandon on 2/25/2015.
 */
public class Person {
    private String name;
    private int age;

    public Person(String n,int a){
        name = n;
        age  = a;

    }
    public String toString(){
        return "Name: "+name+", Age: "+age+" ";

    }


}
